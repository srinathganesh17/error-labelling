# error-labelling
Dataset that contains different error messages and class labels
